CPE453-Lab7
Names:
Parth Ray
Gaurav Joshi

To Compile:
    make virtualmem

To Run:
    ./virtualmem addresses.txt

What we each did:
Parth Ray: Did whole thing together
Gaurav Joshi: Did whole thing together
